import os

from .app import fetch_adoptable_dog_profile_links, fetch_dog_profile, __safe_less_than, cache
from .emailer import send_email
import argparse


# ===========================
# Main (with argparse)
# ===========================

def main():
    """CLI entrypoint for scraping and optional email output."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--clear-cache",
        action="store_true",
        help="Clear disk cache before running"
    )
    args = parser.parse_args()

    if args.clear_cache:
        cache.clear()
        print("Cache cleared.")

    links = fetch_adoptable_dog_profile_links()
    profiles = [fetch_dog_profile(u) for u in links]

    filtered_profiles = [p for p in profiles if __safe_less_than(p.age_months, 8)]
    _ = [send_email(filtered_profiles, send_to=sending) for sending in os.environ["EMAILS_TO"].split(",")]


if __name__ == "__main__":
    main()
